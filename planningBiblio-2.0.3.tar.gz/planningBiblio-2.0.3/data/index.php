<?php
/*
Planning Biblio, Version 2.0.3
Licence GNU/GPL (version 2 et au dela)
Voir les fichiers README.md et LICENSE
Copyright (C) 2011-2015 - Jérôme Combes

Fichier : data/index.php
Création : 8 décembre 2014
Dernière modification : 2 avril 2015
Auteur : Jérôme Combes, jerome@planningbilbio.fr

Description :
Fichier permettant de conserver le dossier data dans git
*/
?>