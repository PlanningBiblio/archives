<?php
/*
Planning Biblio, Version 2.0.3
Licence GNU/GPL (version 2 et au dela)
Voir les fichiers README.md et LICENSE
Copyright (C) 2011-2015 - Jérôme Combes

Fichier : setup/footer.php
Création : mai 2011
Dernière modification : 14 décembre 2012
Auteur : Jérôme Combes, jerome@planningbiblio.fr

Description :
Affiche le pied de page du setup. Appelé par les fichiers index.php, createdb.php et fin.php du dossier setup
*/
?>
</div>
</center>
</body>
</html>